import 'package:flutter/material.dart';

const khorizontlinecolor = Color.fromARGB(255, 237, 234, 234);
const kwhitecolor = Colors.white;
const kgreycolor = Color.fromARGB(255, 104, 104, 104);
const kredColor = Color.fromARGB(255, 229, 7, 7);
const kvioletColor = const Color(0xFF702DE3);
const kbuttonColor = Color.fromARGB(255, 130, 63, 244);
const kblackColor = Colors.black;
const kVerticalLineColor = Color.fromARGB(255, 183, 177, 177);
