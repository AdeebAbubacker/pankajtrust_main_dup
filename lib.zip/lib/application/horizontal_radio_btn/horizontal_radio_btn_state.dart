part of 'horizontal_radio_btn_bloc.dart';

@immutable
 class HorizontalRadioBtnState {
  final int groupValue;

  HorizontalRadioBtnState({required this.groupValue});
 }


 

