part of 'info_content_bloc.dart';

@immutable
sealed class InfoContentState {}

final class InfoContentInitial extends InfoContentState {}
