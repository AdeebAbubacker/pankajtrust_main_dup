part of 'info_content_bloc.dart';

@immutable
sealed class InfoContentEvent {}
