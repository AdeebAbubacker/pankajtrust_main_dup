part of 'check_box_bloc.dart';

@immutable
class CheckBoxState {
  final bool alive;
  final bool bedridden;

  CheckBoxState({
    required this.alive,
    required this.bedridden,
  });
}
