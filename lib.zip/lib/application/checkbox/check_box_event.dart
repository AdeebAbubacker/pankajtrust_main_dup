part of 'check_box_bloc.dart';

@immutable
 class CheckBoxEvent {   bool alive;
  bool bedridden;
  CheckBoxEvent({this.alive = false,this.bedridden= false});
  }





