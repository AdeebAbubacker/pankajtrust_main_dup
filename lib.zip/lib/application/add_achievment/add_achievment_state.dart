part of 'add_achievment_bloc.dart';

@immutable
class AddAchievmentState {final List<Widget> siblingCards;  final int numberOfSiblings;

  AddAchievmentState({required this.siblingCards,this.numberOfSiblings = 1});}







